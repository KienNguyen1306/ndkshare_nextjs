function Loading() {
    return ( <h2 className="loading">🌀 Loading...</h2> );
    
}

export default Loading;