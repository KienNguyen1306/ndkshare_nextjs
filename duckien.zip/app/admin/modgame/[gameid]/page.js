import PutGame from "@/components/AminComponets/game/PutGame";


function PageDetailGame() {
    return ( 
        <PutGame/>
     );
}

export default PageDetailGame;