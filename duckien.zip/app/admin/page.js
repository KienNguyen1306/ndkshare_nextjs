"use client";
import ListGame from "@/components/AminComponets/game/ListGame";
import PostGame from "@/components/AminComponets/game/PostGame";

function AdminPage() {


  
  return (
    <>
      <ListGame />
      <PostGame  />
    </>
  );
}

export default AdminPage;
