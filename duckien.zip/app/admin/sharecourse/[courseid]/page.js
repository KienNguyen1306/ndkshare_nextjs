import ListLession from "@/components/AminComponets/courses/ListLession";
import PutCourse from "../../../../components/AminComponets/courses/PutCourse";

function PageDetail() {

    
  return (
    <>
      {/* <ListLession />
      <PutCourse /> */}
    </>
  );
}

export default PageDetail;
