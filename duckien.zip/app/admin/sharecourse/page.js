"use client";

import ListCourse from "@/components/AminComponets/courses/ListCourse";
import PostCourse from "@/components/AminComponets/courses/PostCourse";


function AdminShareCoures() {

  return (
    <>
      <ListCourse />
      <PostCourse />
    </>
  );
}

export default AdminShareCoures;
